package V1.Controller;
import V1.Model.Post;
import V1.Service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
@SuppressWarnings("unused")
public class HomeController {
    public HomeController(){
        System.out.println("*** Love Controller ***");
    }

    @Autowired
    private PostService postservice;///instance variable

    @RequestMapping("/")
    public String getAllPosts(Model model) {

        List<Post> posts = postservice.getAllP();
        model.addAttribute("posts", posts);
        return "index.html";

    }

}
