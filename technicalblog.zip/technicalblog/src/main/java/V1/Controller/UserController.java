package V1.Controller;

import V1.Model.Post;
import V1.Model.User;
import V1.Service.PostService;
import V1.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;

@Controller
public class UserController {

    @Autowired
    @SuppressWarnings("unused")
    private PostService postservice;

    @RequestMapping ("users/login")
    public String login (){
        return "users/login";
    }
    @RequestMapping ("users/registration")
    public String registration (){
        return "users/registration";
    }
    @RequestMapping (value = "users/login", method = RequestMethod.POST)
    public String loginUser(User user) {
        if (UserService.login(user)) {
            return "redirect:/posts";
        } else {
            return "users/login";
        }
    }
    @RequestMapping (value = "users/registration", method = RequestMethod.POST)
    public String Registration(User user){
        return "users/login";
    }
    @RequestMapping (value = "users/logout", method = RequestMethod.POST)
    public String logout(Model model){
        List<Post> posts = postservice.getAllP();
        model.addAttribute("posts", posts);
        return "index.html";
    }
}
