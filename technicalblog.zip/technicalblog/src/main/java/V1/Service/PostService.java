package V1.Service;
import V1.Model.Post;
import V1.repository.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.Persistent;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.TypedQuery;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class PostService {
    public PostService() {
        System.out.println("*** Love Service ***");
    }

@Autowired
private PostRepository postRepository;

    public List<Post> getAllP() {
       return postRepository.getAll();
    }



    public void createPost (Post newPost){
        newPost.setDate(new Date());
        postRepository.createPost(newPost);
        System.out.println("***This is Working...");
    }
}
