package V1.Service;

import V1.Model.User;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    public static boolean login(User user){
        if (user.getUsername().equals ("Aarav")){
            return true;
        }
        else{
            return false;
        }
    }
}
