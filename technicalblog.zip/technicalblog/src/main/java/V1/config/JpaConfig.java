package V1.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

@Configuration
public class JpaConfig {

    @Bean
    public EntityManagerFactory entityManagerFactory(){
        LocalContainerEntityManagerFactoryBean embf = new LocalContainerEntityManagerFactoryBean();
            embf.setPersistenceXmlLocation("classpath:META-INF/persistence.xml");
            embf.afterPropertiesSet();
            return embf.getObject();
    }

    @Bean
    public DataSource dataSource (){
        DriverManagerDataSource ds = new DriverManagerDataSource();
        ds.setDriverClassName("org.postgresql.Driver");
        ds.setUrl("jdbc:postgresql://localhost:5432/technicalblog\"");
        ds.setUsername("postgres");
        ds.setPassword("Abcd@1234");
        return ds;

    }
}
