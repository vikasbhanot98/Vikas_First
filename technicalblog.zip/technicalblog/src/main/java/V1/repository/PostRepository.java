package V1.repository;

import V1.Model.Post;
import org.springframework.stereotype.Repository;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Repository
public class PostRepository {
    @PersistenceUnit(unitName = "techblog")
    private EntityManagerFactory emf;

    public List<Post> getAll() {
        EntityManager em = emf.createEntityManager();
        TypedQuery<Post> query = em.createQuery("SELECT p from Post p", Post.class);
        List<Post> resultList = query.getResultList();
        return resultList;
    }


    public Post createPost(Post newPost) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction transactions = em.getTransaction();
        try {
            transactions.begin();
            em.persist(newPost);
            transactions.commit();
        }catch(Exception e) {
            transactions.rollback();
        }
        return newPost;
    }
}
